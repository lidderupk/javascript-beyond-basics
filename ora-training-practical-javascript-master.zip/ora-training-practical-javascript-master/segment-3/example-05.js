const arr = [1, 2, 3]

console.log('arr:        ', arr)
console.log('arr mapped: ', arr.map(x => ({ x, x2: x*x })))
