const arr = [1, 2, 3]

console.log('arr:               ', arr)
console.log('arr.map(x => x*x): ', arr.map(x => x*x))
