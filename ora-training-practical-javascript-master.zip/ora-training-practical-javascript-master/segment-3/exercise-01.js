/*
  Modify function below to take an array with the following shape:
    [
      { name: "Widget", price: 3.2943 },
      { name: "Thingy", price 17.9932 },
    ]
  And return an an array of strings suitable for presentation:
    [
      "Widget - $3.29",
      "Thingy - $17.99",
    ]
  Take note of the format; prices should have 2 decimal digits (hint: you can use .toFixed(2) on a
  number to convert it to a string with a fixed number of digits), and make sure the dash is
  surrounded by a single space on either side.
*/
function transform(array) {
}

module.exports = transform
