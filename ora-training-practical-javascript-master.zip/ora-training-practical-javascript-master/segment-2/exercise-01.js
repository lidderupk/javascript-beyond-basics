// modify the following function to take a callback as its only argument; the callback should be invoked with two arguments: null, "green"

function exampleFunction() {
}

module.exports = exampleFunction
