// modify the following function to return a promise that resolves to "green"

function exampleFunction() {
}

module.exports = exampleFunction
