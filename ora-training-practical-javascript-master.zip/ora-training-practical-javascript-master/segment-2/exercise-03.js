// modify the function to take a single argument; the function
// should return a promise that resolves if the argument is "green"
// and rejects if the argument is anything else ("red", for example)

function exampleFunction() {
}

module.exports = exampleFunction
