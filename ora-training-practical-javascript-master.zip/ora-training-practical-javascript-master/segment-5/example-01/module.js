let counter = 0

module.exports = {
  getCount() { return counter },
  increment() { counter++ },
}
