import counter1 from './module.js'
import counter2 from './module.js'

counter1.increment()
counter2.increment()

console.log('counter1: ', counter1.getCounter())
console.log('counter2: ', counter2.getCounter())
