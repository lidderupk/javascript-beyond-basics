let counter = 0

export default {
  getCounter() { return counter },
  increment() { counter++ },
}
