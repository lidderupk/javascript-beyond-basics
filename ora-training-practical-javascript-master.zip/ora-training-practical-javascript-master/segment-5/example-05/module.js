export function hello() {
  console.log('hello!')
}

export function goodbye() {
  console.log('goodbye!')
}
