import { hello, goodbye } from './module.js'

import { hello as hola, goodbye as adios } from './module.js'

hello()
goodbye()

hola()
adios()
